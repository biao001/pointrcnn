import torch
import torch.nn as nn
# 1
from torch_points_kernels import knn
import time


# 2
# import pcdet.ops.RandLA_Net.nearest_neighbors.lib.python.nearest_neighbors as nearest_neighbors


class SharedMLP(nn.Module):
    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size=1,
            stride=1,
            transpose=False,
            padding_mode='zeros',
            bn=False,
            activation_fn=None
    ):
        super(SharedMLP, self).__init__()

        conv_fn = nn.ConvTranspose2d if transpose else nn.Conv2d

        self.conv = conv_fn(
            in_channels,
            out_channels,
            kernel_size,
            stride=stride,
            padding_mode=padding_mode
        )
        self.batch_norm = nn.BatchNorm2d(out_channels, eps=1e-6, momentum=0.99) if bn else None
        self.activation_fn = activation_fn

    def forward(self, input):
        r"""
            Forward pass of the network

            Parameters
            ----------
            input: torch.Tensor, shape (B, d_in, N, K)

            Returns
            -------
            torch.Tensor, shape (B, d_out, N, K)
        """
        x = self.conv(input)
        if self.batch_norm:
            x = self.batch_norm(x)
        if self.activation_fn:
            x = self.activation_fn(x)
        return x


def knn_search(support_pts, query_pts, k):
    """
    :param support_pts: points you have, B*N1*3
    :param query_pts: points you want to know the neighbour index, B*N2*3
    :param k: Number of neighbours in knn search
    :return: neighbor_idx: neighboring points indexes, B*N2*k
    """

    neighbor_idx = nearest_neighbors.knn_batch(support_pts, query_pts, k, omp=True)
    neighbor_idx = torch.from_numpy(neighbor_idx)
    return neighbor_idx


class LocalSpatialEncoding(nn.Module):
    def __init__(self, d, num_neighbors, device):
        super(LocalSpatialEncoding, self).__init__()

        self.num_neighbors = num_neighbors
        self.mlp = SharedMLP(10, d, bn=True, activation_fn=nn.ReLU())

        self.device = device

    @staticmethod
    def gather_neighbour(pc, neighbor_idx):  # pc: batch*npoint*channel
        # gather the coordinates or features of neighboring points
        batch_size = pc.shape[0]
        num_points = pc.shape[1]
        d = pc.shape[2]
        index_input = neighbor_idx.reshape(batch_size, -1)
        features = torch.gather(pc, 1, index_input.unsqueeze(-1).repeat(1, 1, pc.shape[2]))
        features = features.reshape(batch_size, num_points, neighbor_idx.shape[-1], d)  # batch*npoint*nsamples*channel
        return features

    @staticmethod
    def relative_pos_encoding(xyz, neigh_idx):
        neighbor_xyz = LocalSpatialEncoding.gather_neighbour(xyz, neigh_idx)  # batch*npoint*nsamples*3

        xyz_tile = xyz.unsqueeze(2).repeat(1, 1, neigh_idx.shape[-1], 1)  # batch*npoint*nsamples*3
        relative_xyz = xyz_tile - neighbor_xyz  # batch*npoint*nsamples*3
        # batch*npoint*nsamples*1
        relative_dis = torch.sqrt(torch.sum(torch.pow(relative_xyz, 2), dim=-1, keepdim=True))
        relative_dis = relative_dis.squeeze(-1)
        # batch*npoint*nsamples*10
        # relative_feature = torch.cat([relative_dis, relative_xyz, xyz_tile, neighbor_xyz], dim=-1)
        return relative_dis

    def forward(self, coords, features, knn_output):
        r"""
            Forward pass

            Parameters
            ----------
            coords: torch.Tensor, shape (B, N, 3)
                coordinates of the point cloud
            features: torch.Tensor, shape (B, d, N, 1)
                features of the point cloud
            neighbors: tuple

            Returns
            -------
            torch.Tensor, shape (B, 2*d, N, K)
        """
        # finding neighboring points
        # 2
        # idx = knn_output
        # dist = self.relative_pos_encoding(coords, idx)
        # 1
        idx, dist = knn_output
        B, N, K = idx.size()
        # idx(B, N, K), coords(B, N, 3)
        # neighbors[b, i, n, k] = coords[b, idx[b, n, k], i] = extended_coords[b, i, extended_idx[b, i, n, k], k]
        extended_idx = idx.unsqueeze(1).expand(B, 3, N, K)
        extended_coords = coords.transpose(-2, -1).unsqueeze(-1).expand(B, 3, N, K)
        neighbors = torch.gather(extended_coords, 2, extended_idx)  # shape (B, 3, N, K)
        # if USE_CUDA:
        #     neighbors = neighbors.cuda()

        # relative point position encoding
        concat = torch.cat((
            extended_coords,
            neighbors,
            extended_coords - neighbors,
            dist.unsqueeze(-3)
        ), dim=-3).to(self.device)

        return torch.cat((
            self.mlp(concat),
            features.expand(B, -1, N, K)
        ), dim=-3)


class AttentivePooling(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(AttentivePooling, self).__init__()

        self.score_fn = nn.Sequential(
            nn.Linear(in_channels, in_channels, bias=False),
            nn.Softmax(dim=-2)
        )
        self.mlp = SharedMLP(in_channels, out_channels, bn=True, activation_fn=nn.ReLU())

    def forward(self, x):
        r"""
            Forward pass

            Parameters
            ----------
            x: torch.Tensor, shape (B, d_in, N, K)

            Returns
            -------
            torch.Tensor, shape (B, d_out, N, 1)
        """
        # computing attention scores
        scores = self.score_fn(x.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)

        # sum over the neighbors
        features = torch.sum(scores * x, dim=-1, keepdim=True)  # shape (B, d_in, N, 1)

        return self.mlp(features)


class LocalFeatureAggregation(nn.Module):
    def __init__(self, d_in, d_out, num_neighbors, device):
        super(LocalFeatureAggregation, self).__init__()

        self.num_neighbors = num_neighbors

        self.mlp1 = SharedMLP(d_in, d_out // 2, activation_fn=nn.LeakyReLU(0.2))

        self.lse1 = LocalSpatialEncoding(d_out // 2, num_neighbors, device)
        self.pool1 = AttentivePooling(d_out, d_out // 2)

        self.lse2 = LocalSpatialEncoding(d_out // 2, num_neighbors, device)
        self.pool2 = AttentivePooling(d_out, d_out)

        self.mlp2 = SharedMLP(d_out, 2 * d_out)
        self.shortcut = SharedMLP(d_in, 2 * d_out, bn=True)
        self.lrelu = nn.LeakyReLU()
        self.device = device

    def forward(self, coords, features):
        r"""
            Forward pass

            Parameters
            ----------
            coords: torch.Tensor, shape (B, N, 3)
                coordinates of the point cloud
            features: torch.Tensor, shape (B, d_in, N, 1)
                features of the point cloud

            Returns
            -------
            torch.Tensor, shape (B, 2*d_out, N, 1)
        """

        # t0 = time.time()
        # 1
        knn_output = knn(coords.cpu().contiguous(), coords.cpu().contiguous(), self.num_neighbors)
        # 2
        # knn_output = knn_search(coords, coords, self.num_neighbors)
        # t1 = time.time()
        # t2 = t1 - t0
        # print(t2)  # 0.05049196243286133

        x = self.mlp1(features)

        x = self.lse1(coords, x, knn_output)
        x = self.pool1(x)

        x = self.lse2(coords, x, knn_output)
        x = self.pool2(x)

        return self.lrelu(self.mlp2(x) + self.shortcut(features))


class RandLANet(nn.Module):
    def __init__(self, d_in, decode_flag=1, num_classes=2, num_neighbors=16, decimation=4, device=torch.device('cuda:0' if torch.cuda.is_available()
                                                                                                               else
                                                                                                               'cpu')):
        super(RandLANet, self).__init__()
        self.num_neighbors = num_neighbors
        self.decimation = decimation

        self.fc_start = nn.Linear(d_in, 8)
        '''
eps=1e-06: 是为了数值稳定性，在分母中加入的一个小常数，避免除以零的情况。
momentum=0.99: 是动量项，用于平滑地更新移动均值和方差，接近当前批次的统计量但又不过于敏感。
affine=True: 表示除了标准化操作外，还会进行线性变换（加权和偏置），这允许BN层学习并调整输出的尺度和偏移。
track_running_stats=True: 表示在训练过程中会跟踪并更新移动平均和方差，用于推理阶段。
        '''
        self.bn_start = nn.Sequential(
            nn.BatchNorm2d(8, eps=1e-6, momentum=0.99),
            nn.LeakyReLU(0.2)
        )

        # encoding layers
        self.encoder = nn.ModuleList([
            LocalFeatureAggregation(8, 16, num_neighbors, device),
            LocalFeatureAggregation(32, 64, num_neighbors, device),
            LocalFeatureAggregation(128, 128, num_neighbors, device),
            LocalFeatureAggregation(256, 256, num_neighbors, device)
        ])

        self.mlp = SharedMLP(512, 512, activation_fn=nn.ReLU())

        # decoding layers
        decoder_kwargs = dict(
            transpose=True,
            bn=True,
            activation_fn=nn.ReLU()
        )
        self.decoder = nn.ModuleList([
            SharedMLP(1024, 256, **decoder_kwargs),
            SharedMLP(512, 128, **decoder_kwargs),
            SharedMLP(256, 32, **decoder_kwargs),
            SharedMLP(64, 8, **decoder_kwargs)
        ])

        # final semantic prediction
        # self.fc_end = nn.Sequential(
        #     SharedMLP(8, 64, bn=True, activation_fn=nn.ReLU()),
        #     SharedMLP(64, 32, bn=True, activation_fn=nn.ReLU()),
        #     nn.Dropout(),
        #     SharedMLP(32, num_classes)
        # )
        self.fc_end = nn.Sequential(
            SharedMLP(8, 64, bn=True, activation_fn=nn.ReLU()),
            SharedMLP(64, 128, bn=True, activation_fn=nn.ReLU()),
        )
        self.device = device
        self.decode_flag = decode_flag
        self = self.to(device)

    def forward(self, input):
        r"""
            Forward pass

            Parameters
            ----------
            input: torch.Tensor, shape (B, N, d_in)
                input points

            Returns
            -------
            torch.Tensor, shape (B, num_classes, N)
                segmentation scores for each point
        """
        N = input.size(1)
        d = self.decimation

        coords = input[..., :3].clone().cpu()
        # coords = input[..., :3].clone()
        x = self.fc_start(input).transpose(-2, -1).unsqueeze(-1)
        x = self.bn_start(x)  # shape (B, d, N, 1)

        decimation_ratio = 1

        # t0 = time.time()

        # <<<<<<<<<< ENCODER
        x_stack = []

        permutation = torch.randperm(N)
        coords = coords[:, permutation]
        x = x[:, :, permutation]

        for lfa in self.encoder:
            # at iteration i, x.shape = (B, N//(d**i), d_in)
            x = lfa(coords[:, :N // decimation_ratio], x)
            x_stack.append(x.clone())
            decimation_ratio *= d
            x = x[:, :, :N // decimation_ratio]

        # # >>>>>>>>>> ENCODER
        # t1 = time.time()
        # t2 = t1 - t0
        # print(t2)  # 0.14766216278076172

        x = self.mlp(x)

        if self.decode_flag == 0:
            x = x[:, :, torch.argsort(permutation)]
            x = x.squeeze(-1).permute(0, 2, 1).contiguous()
            return x
        else:
            # t0 = time.time()
            # <<<<<<<<<< DECODER
            for mlp in self.decoder:
                # 1
                neighbors, _ = knn(
                    coords[:, :N // decimation_ratio].cpu().contiguous(),  # original set
                    coords[:, :d * N // decimation_ratio].cpu().contiguous(),  # upsampled set
                    1
                )  # shape (B, N, 1)
                # 2
                # neighbors = knn_search(
                #     coords[:, :N // decimation_ratio],
                #     coords[:, :d * N // decimation_ratio], 1)
                neighbors = neighbors.to(self.device)
                extended_neighbors = neighbors.unsqueeze(1).expand(-1, x.size(1), -1, 1)

                x_neighbors = torch.gather(x, -2, extended_neighbors)

                x = torch.cat((x_neighbors, x_stack.pop()), dim=1)

                x = mlp(x)

                decimation_ratio //= d

            # >>>>>>>>>> DECODER
            # t1 = time.time()
            # t2 = t1 - t0
            # print(t2)  # 0.01298069953918457
            # inverse permutation
            x = x[:, :, torch.argsort(permutation)]
            x = self.fc_end(x)
            x = x.squeeze(-1).permute(0, 2, 1).contiguous()
            return x

        # scores = self.fc_end(x)
        # return scores.squeeze(-1)


if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    d_in = 7
    cloud = 1000 * torch.randn(4, 2 ** 14, d_in).to(device)
    model = RandLANet(d_in)
    # model = model.to(device)
    # model.load_state_dict(torch.load('checkpoints/checkpoint_100.pth'))
    # model.eval()
    t0 = time.time()
    features = model(cloud)
    t1 = time.time()
    t2 = t1 - t0
    print(t2)
