from sklearn.neighbors import KDTree
import numpy as np
import pcdet.ops.RandLA_Net.cpp_wrappers.cpp_subsampling.grid_subsampling as cpp_subsampling
import pcdet.ops.RandLA_Net.nearest_neighbors.lib.python.nearest_neighbors as nearest_neighbors


class DataProcessing:
    @staticmethod
    def knn_search(support_pts, query_pts, k):
        """
        :param support_pts: points you have, B*N1*3
        :param query_pts: points you want to know the neighbour index, B*N2*3
        :param k: Number of neighbours in knn search
        :return: neighbor_idx: neighboring points indexes, B*N2*k
        """

        neighbor_idx = nearest_neighbors.knn_batch(support_pts, query_pts, k, omp=True)
        return neighbor_idx

    @staticmethod
    def grid_sub_sampling(points, features=None, labels=None, grid_size=0.1, verbose=0):
        """
        CPP wrapper for a grid sub_sampling (method = barycenter for points and features
        :param points: (N, 3) matrix of input points
        :param features: optional (N, d) matrix of features (floating number)
        :param labels: optional (N,) matrix of integer labels
        :param grid_size: parameter defining the size of grid voxels
        :param verbose: 1 to display
        :return: sub_sampled points, with features and/or labels depending of the input
        """

        if (features is None) and (labels is None):
            return cpp_subsampling.compute(points, sampleDl=grid_size, verbose=verbose)
        elif labels is None:
            return cpp_subsampling.compute(points, features=features, sampleDl=grid_size, verbose=verbose)
        elif features is None:
            return cpp_subsampling.compute(points, classes=labels, sampleDl=grid_size, verbose=verbose)
        else:
            return cpp_subsampling.compute(points, features=features, classes=labels, sampleDl=grid_size,
                                           verbose=verbose)

    @staticmethod
    def sub_search(points, features=None, labels=None, grid_size=0.1, verbose=0):
        sub_points = DataProcessing.grid_sub_sampling(points=points, features=features, labels=labels, grid_size=0.06, verbose=verbose)
        search_tree = KDTree(sub_points)
        proj_inds = np.squeeze(search_tree.query(points, return_distance=False))
        proj_inds = proj_inds.astype(np.int32)
        return proj_inds
