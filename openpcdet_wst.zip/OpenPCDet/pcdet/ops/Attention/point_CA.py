import torch
from torch import nn
from torch.nn import functional as F


class PointChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(PointChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.shared_MLP = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.shared_MLP(self.avg_pool(x))  # （B，C，1，1）
        max_out = self.shared_MLP(self.max_pool(x))
        out = avg_out + max_out
        out = self.sigmoid(out) * x
        return out


if __name__ == '__main__':
    channels = 128
    point = torch.randn(128, channels, 512, 1)
    net = PointChannelAttention(channels)
    print(net)
    out = net(point)
    print(out.size())
    print('point', point[0])
    print('out', out[0])
