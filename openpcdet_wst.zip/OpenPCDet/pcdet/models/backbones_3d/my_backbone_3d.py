import torch
import torch.nn as nn

from ...ops.RandLA_Net import RLA_modules


class MyBackbone3d(nn.Module):
    def __init__(self, model_cfg, input_channels, **kwargs):
        super().__init__()
        self.model_cfg = model_cfg
        self.RLA_model = RLA_modules.RandLANet(input_channels)
        self.num_point_features = self.model_cfg.FC_end

    def break_up_pc(self, pc):
        batch_idx = pc[:, 0]
        xyz = pc[:, 1:4].contiguous()
        features = pc[:, 1:].contiguous() if pc.size(-1) > 4 else None
        return batch_idx, xyz, features

    def forward(self, batch_dict):
        """
        Args:
            batch_dict:
                batch_size: int
                vfe_features: (num_voxels, C)
                points: (num_points, 4 + C), [batch_idx, x, y, z, ...]
        Returns:
            batch_dict:
                encoded_spconv_tensor: sparse tensor
                point_features: (N, C)
        """
        batch_size = batch_dict["batch_size"]
        points = batch_dict["points"]
        batch_idx, xyz, features = self.break_up_pc(points)

        xyz_batch_cnt = xyz.new_zeros(batch_size).int()
        for bs_idx in range(batch_size):
            xyz_batch_cnt[bs_idx] = (batch_idx == bs_idx).sum()

        assert xyz_batch_cnt.min() == xyz_batch_cnt.max()
        xyz = xyz.view(batch_size, -1, 3)
        features = (
            features.view(batch_size, -1, features.shape[-1])
            .contiguous()
            if features is not None
            else None
        )
        point_features = self.RLA_model(features)  # (B, N, C)
        batch_dict["point_features"] = point_features.view(-1, point_features.shape[-1])
        batch_dict["point_coords"] = torch.cat(
            (batch_idx[:, None].float(), xyz.view(-1, 3)), dim=1
        )
        return batch_dict
